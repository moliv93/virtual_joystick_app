import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:io';
import 'dart:typed_data';
import 'dart:math';

const A_BIN_INDEX = 0;
const B_BIN_INDEX = 1;
const Y_BIN_INDEX = 2;
const X_BIN_INDEX = 3;
const R_BIN_INDEX = 4;
const L_BIN_INDEX = 5;
const SELECT_BIN_INDEX = 6;
const START_BIN_INDEX = 7;

class JoystickUI extends StatefulWidget {
  const JoystickUI({Key? key, this.title = 'ui of joystick', required this.socket, required this.hostIP}) : super(key: key);

  final String title;
  final RawDatagramSocket socket;
  final String hostIP;

  @override
  _JoystickUIState createState() => _JoystickUIState(socket: socket, hostIP: hostIP);
}

final _counter = ValueNotifier<int>(0);

class _JoystickUIState extends State<JoystickUI> {
  _JoystickUIState({required this.socket, required this.hostIP}) : super();

  final RawDatagramSocket socket;
  final String hostIP;
  int port = 2812;
  JoystickPainter joystick = JoystickPainter(notifier: _counter);
  int _downCounter = 0;
  int _upCounter = 0;
  double x = 0.0;
  double y = 0.0;
  String oldData = '';

  @override
  void initState() {
    super.initState();
    // RawDatagramSocket.bind(InternetAddress.anyIPv4, 55555).then((value) {
    //   socket = value;
    //   socket.broadcastEnabled = true;
    // });
    // socket.broadcastEnabled = true;
  }  

  void _incrementDown(PointerEvent details) {
    joystick.updateStatesPress(details);
    _counter.value++;
    // _updateLocation(details);
    setState(() {
      // joystick.isBPressed = true;
      // _downCounter++;
    });
  }

  void _incrementUp(PointerEvent details) {
    joystick.updateStatesRelease(details);
    _counter.value++;
    // _updateLocation(details);
    setState(() {
      // joystick.isBPressed = false;
      // _upCounter++;
    });
  }

  void _updateLocation(PointerEvent details) {
    joystick.updateStatesMove(details);
    _counter.value++;
    setState(() {
      // x = details.position.dx;
      // y = details.position.dy;
      // joystick.buttonCenter = details.position;
      // print(joystick.buttonCenter);
    });
  }

  void send_data() {
    String buttonData = joystick.generateButtonData();
    print(buttonData);
    if (buttonData != oldData) {
      oldData = buttonData;
      socket.send(buttonData.codeUnits, InternetAddress(hostIP), port);
    }
    // List<int> datagram = [];
    // datagram.add(buttonData);
    
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.leanBack);
    send_data();
    return Scaffold(
      body: Container(
        child: Listener(
          onPointerDown: _incrementDown,
          onPointerMove: _updateLocation,
          onPointerUp: _incrementUp,
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            color: Colors.white,
            child: CustomPaint(painter: joystick),
          ),
        ),
      )
    );
  }
}

class CanvasHandler {
  double effectRadius = 100;
  Offset center = Offset(200, 300);
  double handlerRadius = 40;
  Offset handlerCenter = Offset(200, 300);
  double xDrag = 0;
  double yDrag = 0;
  Offset drag = Offset(0, 0);
  int controlPointer = -1;
  Paint backgroundPaint = Paint();
  Paint handlerPaint = Paint();

  CanvasHandler({
    double effectRadius = 100,
    double centerX = 200,
    double centerY = 300,
    double handlerRadius = 40,
    Color backgroundColor = Colors.indigo,
    Color handlerColor = Colors.blue,
  }) {
    this.effectRadius = effectRadius;
    this.center = Offset(centerX, centerY);
    this.handlerRadius = handlerRadius;
    this.handlerCenter = this.center;
    this.backgroundPaint = Paint()
                    ..style = PaintingStyle.fill
                    ..color = backgroundColor;
    this.handlerPaint = Paint()
                    ..style = PaintingStyle.fill
                    ..color = handlerColor;
  }

  void activate(PointerEvent details) {
    if (controlPointer != -1) return;
    Offset distance = details.position - center;
    if (sqrt(pow(distance.dx, 2) + pow(distance.dy, 2)) <= effectRadius) {
      controlPointer = details.pointer;
      drag = distance;
      if (drag.distance > effectRadius) {
        drag = drag.scale(1/drag.distance, 1/drag.distance) * effectRadius;
      }
      handlerCenter = center+drag;
    }
  }

  void deactivate(PointerEvent details) {
    if (controlPointer == details.pointer) {
      controlPointer = -1;
      drag = Offset(0, 0);
    }
    handlerCenter = center+drag;
  }

  void move_test(PointerEvent details) {
    if (controlPointer != details.pointer) return;
    Offset distance = details.position - center;
    drag = distance;
    if (drag.distance > effectRadius) {
      drag = drag.scale(1/drag.distance, 1/drag.distance) * effectRadius;
    }
    handlerCenter = center+drag;
    // if (controlPointer == -1) {

    // }
    // if (controlPointer == details.pointer) {
      
    // }
    // Offset distance = details.position - center;
    // if (sqrt(pow(distance.dx, 2) + pow(distance.dy, 2)) <= bigRadius) {
    //   pointers.add(details.pointer);
    //   isPressed = pointers.length > 0;
    // }
    // else {
    //   pointers.remove(details.pointer);
    //   isPressed = pointers.length > 0;
    // }
  }
}

class CanvasButton {
  bool isPressed = false;
  Set<int> pointers = Set();
  double bigRadius = 40;
  double smallRadius = 35;
  Offset center = Offset(775, 200);
  Paint backgroundPaint = Paint();
  Paint normalPaint = Paint();
  Paint pressedPaint = Paint();
  TextStyle textStyle = TextStyle();
  TextSpan textSpan = TextSpan();
  TextPainter textPainter = TextPainter();
  Offset textOffset = Offset(10, 20);

  CanvasButton({String text = 'B',
                double bigRadius = 40,
                double smallRadius = 35,
                double centerX = 500,
                double centerY = 500,
                Color backgroundColor = Colors.black,
                Color normalColor = Colors.red,
                Color pressedColor = Colors.yellow,
                Color textColor = Colors.black,
                double textOffsetX = 10,
                double textOffsetY = 20,
                double fontSize = 35}) {
                  this.bigRadius = bigRadius;
                  this.smallRadius = smallRadius;
                  this.center = Offset(centerX, centerY);
                  this.textOffset = Offset(textOffsetX, textOffsetY);
                  this.backgroundPaint = Paint()
                    ..style = PaintingStyle.fill
                    ..color = backgroundColor;
                  this.normalPaint = Paint()
                    ..style = PaintingStyle.fill
                    ..color = normalColor;
                  this.pressedPaint = Paint()
                    ..style = PaintingStyle.fill
                    ..color = pressedColor;
                  this.textStyle = TextStyle(
                    color: textColor,
                    fontSize: fontSize,
                  );
                  this.textSpan = TextSpan(
                    text: text,
                    style: this.textStyle,
                  );
                  this.textPainter = TextPainter(
                    text: this.textSpan,
                    textDirection: TextDirection.ltr,
                  );
                  this.textPainter.layout(
                    minWidth: 0,
                  );
  }

  void activate(PointerEvent details) {
    Offset distance = details.position - center;
    if (sqrt(pow(distance.dx, 2) + pow(distance.dy, 2)) <= bigRadius) {
      pointers.add(details.pointer);
    }
    if (pointers.length > 0) {
      isPressed = true;
    }
    else {
      isPressed = false;
    }
  }

  void deactivate(PointerEvent details) {
    if (!pointers.contains(details.pointer)) return;
    Offset distance = details.position - center;
    if (sqrt(pow(distance.dx, 2) + pow(distance.dy, 2)) <= bigRadius) {
      pointers.remove(details.pointer);
    }
    if (pointers.length > 0) {
      isPressed = true;
    }
    else {
      isPressed = false;
    }
  }

  void move_test(PointerEvent details) {
    Offset distance = details.position - center;
    if (sqrt(pow(distance.dx, 2) + pow(distance.dy, 2)) <= bigRadius) {
      pointers.add(details.pointer);
      isPressed = pointers.length > 0;
    }
    else {
      pointers.remove(details.pointer);
      isPressed = pointers.length > 0;
    }
  }
}

class JoystickPainter extends CustomPainter {
  ValueNotifier<int> notifier;
  Map<String, CanvasButton> buttons = Map();
  CanvasHandler handler = CanvasHandler();
  Paint handlerBackgroundPaint = Paint()
                    ..style = PaintingStyle.fill
                    ..color = Colors.indigo.shade100;
  Paint handlerPaint = Paint()
                    ..style = PaintingStyle.fill
                    ..color = Colors.indigo.shade400;

  JoystickPainter({required this.notifier}) : super(repaint: notifier) {
    handler = CanvasHandler(
      effectRadius: 100,
      centerX: 200-30,
      centerY: 200,
      handlerRadius: 40,
      backgroundColor: Colors.indigo.shade100,
      handlerColor: Colors.indigo.shade400,
    );

    buttons['A'] = CanvasButton(
      text: 'A',
      centerX: 700-30,
      centerY: 300,
      normalColor: Colors.green.shade800,
      pressedColor: Colors.green.shade400,
    );

    buttons['B'] = CanvasButton(
      text: 'B',
      centerX: 800-30,
      centerY: 200,
      normalColor: Colors.red.shade800,
      pressedColor: Colors.red.shade400,
    );

    buttons['Y'] = CanvasButton(
      text: 'Y',
      centerX: 700-30,
      centerY: 100,
      normalColor: Colors.yellow.shade800,
      pressedColor: Colors.yellow.shade400,
    );

    buttons['X'] = CanvasButton(
      text: 'X',
      centerX: 600-30,
      centerY: 200,
      normalColor: Colors.blue.shade800,
      pressedColor: Colors.blue.shade400,
    );

    buttons['R'] = CanvasButton(
      text: 'R',
      centerX: 800-30,
      centerY: 50,
      normalColor: Colors.grey.shade600,
      pressedColor: Colors.grey.shade300,
    );

    buttons['L'] = CanvasButton(
      text: 'L',
      centerX: 100-30,
      centerY: 50,
      normalColor: Colors.grey.shade600,
      pressedColor: Colors.grey.shade300,
    );

    buttons['Select'] = CanvasButton(
      text: 'Select',
      centerX: 350-30,
      centerY: 300,
      normalColor: Colors.grey.shade600,
      pressedColor: Colors.grey.shade300,
      fontSize: 20,
      textOffsetX: 25,
      textOffsetY: 15,
    );

    buttons['Start'] = CanvasButton(
      text: 'Start',
      centerX: 550-30,
      centerY: 300,
      normalColor: Colors.grey.shade600,
      pressedColor: Colors.grey.shade300,
      fontSize: 20,
      textOffsetX: 20,
      textOffsetY: 15,
    );
  }

  void updateStatesPress(PointerEvent details) {
    buttons.forEach((String k, CanvasButton b) {
      b.activate(details);
    });

    handler.activate(details);
  }

  void updateStatesRelease(PointerEvent details) {
    buttons.forEach((String k, CanvasButton b) {
      b.deactivate(details);
    });

    handler.deactivate(details);
  }

  void updateStatesMove(PointerEvent details) {
    buttons.forEach((String k, CanvasButton b) {
      b.move_test(details);
    });

    handler.move_test(details);
  }

  String generateButtonData() {
    String data = '';
    data = data + (buttons['A']!.isPressed ? '1' : '0');
    data = data + (buttons['B']!.isPressed ? '1' : '0');
    data = data + (buttons['Y']!.isPressed ? '1' : '0');
    data = data + (buttons['X']!.isPressed ? '1' : '0');
    data = data + (buttons['R']!.isPressed ? '1' : '0');
    data = data + (buttons['L']!.isPressed ? '1' : '0');
    data = data + (buttons['Select']!.isPressed ? '1' : '0');
    data = data + (buttons['Start']!.isPressed ? '1' : '0');
    data = data + '/' + handler.drag.dx.round().toString() + '/' + handler.drag.dy.round().toString();
    // int data = 0;
    // if (buttons['A']!.isPressed) data += 1;
    // if (buttons['B']!.isPressed) data += 2;
    // if (buttons['Y']!.isPressed) data += 4;
    // if (buttons['X']!.isPressed) data += 8;
    // if (buttons['R']!.isPressed) data += 16;
    // if (buttons['L']!.isPressed) data += 32;
    // if (buttons['Select']!.isPressed) data += 64;
    // if (buttons['Start']!.isPressed) data += 128;
    // data = data | (buttons['A']!.isPressed.hashCode << A_BIN_INDEX);
    // data = data | (buttons['B']!.isPressed.hashCode << B_BIN_INDEX);
    // data = data | (buttons['Y']!.isPressed.hashCode << Y_BIN_INDEX);
    // data = data | (buttons['X']!.isPressed.hashCode << X_BIN_INDEX);
    // data = data | (buttons['R']!.isPressed.hashCode << R_BIN_INDEX);
    // data = data | (buttons['L']!.isPressed.hashCode << L_BIN_INDEX);
    // data = data | (buttons['Select']!.isPressed.hashCode << SELECT_BIN_INDEX);
    // data = data | (buttons['Start']!.isPressed.hashCode << START_BIN_INDEX);
    return data;
  }

  @override
  void paint(Canvas canvas, Size size) {
    buttons.forEach((String k, CanvasButton b) {
      canvas.drawCircle(b.center, b.bigRadius, b.backgroundPaint);
      canvas.drawCircle(b.center, b.smallRadius, b.isPressed ? b.pressedPaint : b.normalPaint);
      b.textPainter.paint(canvas, b.center-b.textOffset);
    });

    canvas.drawCircle(handler.center, handler.effectRadius, handler.backgroundPaint);
    canvas.drawCircle(handler.handlerCenter, handler.handlerRadius, handler.handlerPaint);
  }

  @override
  bool shouldRepaint(JoystickPainter oldDelegate) => true;
}